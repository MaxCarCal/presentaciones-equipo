import org.example.models.ConnectDB;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class clasificarR extends JFrame {
    private JComboBox<String> zoneBox, crimeTypeBox;
    private JTable table;
    private String[][] reports;

    public clasificarR() {
        setTitle("Clasificación de Reportes");
        setSize(600, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        String[] zones = {"Todos", "Cholula", "Cuautlancingo", "Central de Abastos", "Parque Industrial", "La Paz", "San Baltazar Campeche", "Angelopolis"};
        String[] crimeTypes = {"Todos", "Robo de autopartes", "Asalto", "Secuestro"};

        zoneBox = new JComboBox<>(zones);
        crimeTypeBox = new JComboBox<>(crimeTypes);
        JButton filterButton = new JButton("Filtrar");

        JPanel filterPanel = new JPanel();
        filterPanel.add(new JLabel("Zona:"));
        filterPanel.add(zoneBox);
        filterPanel.add(new JLabel("Delito:"));
        filterPanel.add(crimeTypeBox);
        filterPanel.add(filterButton);

        reports = fetchReportsFromDB(null, null);
        table = new JTable(reports, new String[]{"Zona", "Área", "Tipo de Delito", "Descripción"});

        filterButton.addActionListener(e -> filterReports());

        add(filterPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        setVisible(true);
    }

    private void filterReports() {
        String selectedZone = (String) zoneBox.getSelectedItem();
        String selectedCrime = (String) crimeTypeBox.getSelectedItem();

        String[][] filtered = fetchReportsFromDB(
                selectedZone.equals("Todos") ? null : selectedZone,
                selectedCrime.equals("Todos") ? null : selectedCrime
        );

        table.setModel(new javax.swing.table.DefaultTableModel(
                filtered,
                new String[]{"Zona", "Área", "Tipo de Delito", "Descripción"}
        ));
    }

    private String[][] fetchReportsFromDB(String zona, String tipoDelito) {
        ArrayList<String[]> reportList = new ArrayList<>();
        ConnectDB db = new ConnectDB();
        Connection conn = db.getConnection();

        if (conn != null) {
            try {
                String query = "SELECT zona, area, tipo_delito, descripcion FROM reports WHERE 1=1";
                if (zona != null) query += " AND zona = ?";
                if (tipoDelito != null) query += " AND tipo_delito = ?";

                PreparedStatement ps = conn.prepareStatement(query);

                int paramIndex = 1;
                if (zona != null) ps.setString(paramIndex++, zona);
                if (tipoDelito != null) ps.setString(paramIndex, tipoDelito);

                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    reportList.add(new String[]{
                            rs.getString("zona"),
                            rs.getString("area"),
                            rs.getString("tipo_delito"),
                            rs.getString("descripcion")
                    });
                }

                rs.close();
                ps.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                db.closeConnection();
            }
        }
        return reportList.toArray(new String[0][]);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(clasificarR::new);
    }
}

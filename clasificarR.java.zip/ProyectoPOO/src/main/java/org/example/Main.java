package org.example;

import org.example.models.ConnectDB;
import java.sql.*;

public class Main {
    public static void main(String[] args) {
        ConnectDB db = new ConnectDB();
        Connection connection = db.getConnection();

        if (connection != null) {
            try {
                Statement statement = connection.createStatement();

                // Crear tabla "reports" si no existe
                String createReportsTable = "CREATE TABLE IF NOT EXISTS reports (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "zona TEXT," +
                        "area TEXT," +
                        "tipo_delito TEXT," +
                        "descripcion TEXT)";
                statement.executeUpdate(createReportsTable);

                // Insertar datos de ejemplo
                statement.executeUpdate("INSERT INTO reports (zona, area, tipo_delito, descripcion) VALUES " +
                        "('Cholula', 'San Andres', 'Robo de autopartes', 'Se llevaron las llantas')," +
                        "('Cuautlancingo', 'Momoxpan', 'Asalto', 'Asalto a mano armada')," +
                        "('Central de Abastos', 'San Jeronimo', 'Secuestro', 'Persona desaparecida')," +
                        "('Parque Industrial', 'Encinos', 'Robo de autopartes', 'Vidrios rotos y robo')," +
                        "('La Paz', 'Bello Horizonte', 'Asalto', 'Robo de celular')," +
                        "('San Baltazar Campeche', 'Tres Cruces', 'Secuestro', 'Intento de rapto')," +
                        "('Angelopolis', 'Chulavista', 'Robo de autopartes', 'Se llevaron espejos')");

                System.out.println("Datos insertados en la base de datos.");

                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                db.closeConnection();
            }
        } else {
            System.out.println("Error al conectar con la base de datos.");
        }
    }
}
